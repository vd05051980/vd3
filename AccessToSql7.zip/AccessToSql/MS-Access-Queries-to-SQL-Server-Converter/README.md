# MS Access Queries to SQL Server Converter
  Approved by Editor or trusted author Tagged as VB.NET Stats 4.5K views 505 downloads 7 bookmarked Deleted MS Access Queries to SQL Server Converter  Igor Krupitsky 20 Sep 2019 CPOL Tool for Migrating MS Access Queries to SQL Server. It should be used when the Access Queries are using SQL server linked tables.
